from gender_predictor import GenderNames, GenderPredictor, get_predictor_from_file, get_predictor_from_pickle

if __name__ == '__main__':

    # Example 1 how use it
    print("Example 1:")
    gn = GenderNames()
    gn = gn.load_from_files(path_female='data/female.txt', path_male='data/male.txt')
    # save for the second example (path is optional argument)
    gn = gn.save_to_pickle(path='data/data.pickle')
    # labels is optional (default: Female, Male)
    gp = GenderPredictor(gn, female_label='Female', male_label='Male')
    print(gp.get_gender('Yevhenii'))
    print()

    # Example 2 how use it
    print("Example 2:")
    gn = GenderNames()
    gn = gn.load_from_pickle(path='data/data.pickle')
    gp = GenderPredictor(gn, female_label='1', male_label='0')
    print(gp.get_gender('Yevhenii'))
    print()

    # Wrapper under 1 example how use it
    # All arguments is optional
    print("Example 3:")
    gp = get_predictor_from_file(path_female='data/female.txt', path_male='data/male.txt')
    print(gp.get_gender('Yevhenii'))
    print()


    # Wrapper under 2 example how use it
    # All arguments is optional
    print("Example 4")
    gp = get_predictor_from_pickle(path='data/data.pickle')
    print(gp.get_gender('Yevhenii'))
    print()




